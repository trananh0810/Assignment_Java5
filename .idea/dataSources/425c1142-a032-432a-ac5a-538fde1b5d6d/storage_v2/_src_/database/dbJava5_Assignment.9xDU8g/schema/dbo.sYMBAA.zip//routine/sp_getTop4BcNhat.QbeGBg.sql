CREATE PROC [dbo].[sp_getTop4BcNhat]
AS
BEGIN
    SELECT TOP 4 dbo.Product.id, dbo.Product.name, dbo.Product.image,dbo.Product.price FROM dbo.Product
	INNER JOIN dbo.OrderDetail ON OrderDetail.productId = Product.id
	GROUP BY dbo.Product.id, dbo.Product.name, dbo.Product.image, dbo.Product.price
	ORDER BY SUM(dbo.OrderDetail.quantity) DESC
END
go

